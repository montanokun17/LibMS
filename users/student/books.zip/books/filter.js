function filterBooks(books) {
    // Make an AJAX request based on the status clicked
    $.ajax({
      url: "/LibMS/users/student/books/filter.php", // Replace with your backend file to handle fetching jobs by status
      type: "GET",
      data: { status: books }, // Send the status to the backend
      success: function(data) {
        // Update the job posting container with the fetched data
        document.getElementById("#dataTable").innerHTML = data;
      },
      error: function() {
        document.getElementById("#dataTable").innerHTML = "Failed to retrieve job postings";
      }
    });
}